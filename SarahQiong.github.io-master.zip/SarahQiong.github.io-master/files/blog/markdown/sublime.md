---
output:
  pdf_document: default
  html_document: default
header-includes: \usepackage{graphicx}
---

## Sublime for Research

**Last updated:**

1. Sublime to compile LaTeX

https://plaintext-productivity.net/2-04-how-to-set-up-sublime-text-for-markdown-editing.html



Package install: Command+Shift+P




2. Sublime to compile markdown file (can be used to create pdf files and html blog)


3. python automatic format PyYaf




References:

1. https://joshnutt.com/Setting-Up-Sublime-Text-for-Markdown-Files/
2. 